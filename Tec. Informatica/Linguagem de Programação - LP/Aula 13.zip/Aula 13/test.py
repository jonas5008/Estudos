import pyautogui
import time

time.sleep(5)

im2= pyautogui.screenshot('imagem.png')

#Ele tira uma print da tela inteira

