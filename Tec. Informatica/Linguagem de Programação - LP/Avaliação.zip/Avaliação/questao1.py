num1 = int (input("Digite o primeiro numero: "))

print(num1)

num2 = int (input("Digite o segundo numero: "))

print(num2)

if num1 > num2:

    print(f"O maior é {num1}")
else:
    print(f"O maior é {num2}")

