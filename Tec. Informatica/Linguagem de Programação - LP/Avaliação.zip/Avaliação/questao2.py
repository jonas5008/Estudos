def saudacao(nome="Visitante"):
    print("-" * 30)

saudacao(nome="Visitante")
print("Olá, seja bem vindo ao meu programa")
saudacao(nome="Visitante")
print("É um prazer enorme ter você aqui")
saudacao(nome="Visitante")
