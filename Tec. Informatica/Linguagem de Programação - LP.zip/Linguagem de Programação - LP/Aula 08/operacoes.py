def soma (a, b):
    s = a + b
    return(s)




def Subtracao (c, d):
    S = c - d
    return(S)




def multiplicacao (e, f):
    m = e * f
    return(m)




def divisao (g, h):
    d = g / h
    return(d)


def metro_centimetros(m):
    return m * 100

def centimetros_metros(cm):
    return cm/100

def km_metros(km):
    return km * 1000
