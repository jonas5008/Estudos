valor = int (input("digite sua idade:"))

if valor >18:

    print("voce pode dividir")

else: 

    print("voce pode dirigir")




nota1 = float (input("digite a primeira nota:"))

print (nota1)

nota2 = float (input("digite a segunda nota:"))

print (nota2)

media = (nota1 + nota2) /2

print ("media",media)

if media > 6:
    print ("aprovado")

else:
    print("reprovado")

