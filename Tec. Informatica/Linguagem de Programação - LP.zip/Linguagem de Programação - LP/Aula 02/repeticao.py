contador = 1

while contador <= 5:
    print("numero:", contador)
    contador += 1

for I in range (1,5):
 print(I)

#for<contado> in range(valorinicial, valorfinal, passo)

for I in range(1,20,2):
 print(I)

 