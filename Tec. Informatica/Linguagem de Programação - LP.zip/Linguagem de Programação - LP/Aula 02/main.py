x = int (input("digite o valor para x:"))

print (x)

y = int(input("digite o valor para y:"))

print (y)

z= (x**2+y**2)/(x+y)**2

print ("z=",z)

#exemplo prático para usar mod. (resto)

total_meses = 170

ano = total_meses // 12

meses = total_meses % 12

print("o consórcio é de", ano, "anos e", meses, "meses.")

