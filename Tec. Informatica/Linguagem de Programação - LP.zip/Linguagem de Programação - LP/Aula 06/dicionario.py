pessoa ={
"nome":"jonas",
"idade":22,
"peso":88,
}

print(pessoa)

print(pessoa["nome"]) #so mostra uma casinha que eu quero

print(pessoa["idade"])

print(pessoa["peso"])

print(pessoa.keys())

print(pessoa.values())

pessoa ["altura"] = 1.75 #acrecenta ou modifica

print (pessoa)

pessoa ["peso"] = 80

print (pessoa)

del pessoa ["idade"] #ele deleta

print (pessoa)

print ("nome" in pessoa)
False

print ("idade" in pessoa)
True



#atributo : valor ele mostra a caracteristica

