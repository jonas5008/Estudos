numero = [2, 5, 10, 1, 4, 9, 22, 100,3]

print(len(numero))

print(min(numero))

print(max(numero))

print(sum(numero))

print(sorted(numero))

print(sorted(numero,reverse=True))

print(numero[1])

print(100 in numero) #pergunte se tem esse numero

print(numero) #mostra a lista

print(numero[2:8]) #ele nao mostra o ultimo

print(numero[:2]) #começa antes do 2

print(numero[2:]) #começa no 2

del numero [1]
print(numero)  #ele o numero que voce pedir na lista

numero.append(102) #ele acrencenta no final da lista
print(numero)



#len: ele fala o tamanho da lista

#min: menor numero da lista

#max: maior numero da lista

#sum: soma de todos

#sorted: ele organiza do menor para o maior

#sorted numero,reverse=True: ele organiza do maior para o menor
