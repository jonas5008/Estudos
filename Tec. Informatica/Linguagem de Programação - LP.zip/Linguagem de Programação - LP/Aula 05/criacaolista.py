l1= list (range(5)) #vai escreve a lista mas nao vai colocar o ultimo
print(l1)

l2= list (range(3,8)) #começo e fim da lista
print(l2)

l3= list (range(2,11,3)) #escreve em passos, nesse caso é de 3 em 3
print(l3)

