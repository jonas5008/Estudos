def mostra_linha():
    print("-" * 30)


mostra_linha()
print("quiz-feira cultural")
mostra_linha()
print("questao 1")
mostra_linha()
print("questao 2")
mostra_linha()
