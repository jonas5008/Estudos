def divisao(a, b):
    d = a / b
    print(d)

divisao(10, 2)
