def par_ou_impar(n):
    if n % 2 == 0:
     print("par")
    else:
     print("impar")

par_ou_impar(2)
