def soma(a, b):
    s= a + b
    print(s)


soma(5, 3)

#O seu soma tem que tá colodo na parede para somar
