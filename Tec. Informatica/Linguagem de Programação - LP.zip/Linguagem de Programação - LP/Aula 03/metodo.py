x = input("digite algo")
print ("É um numero? ", x.isnumeric())
print ("É um alfanumerico (números e letras)? ", x.isalnum())
print ("É um alfabetico? (letras) ", x.isalpha())
print ("Está em minúsculo? ", x.islower())
print ("Está em maiúsculo? ", x.isupper())
print ("É somente espaço? ", x.isspace())
print ("Está capitalizada (Possui maiúsculas e minúsculas?) ", x.istitle())


