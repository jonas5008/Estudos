import math
print (math.sqrt(16))

print (math.factorial(6))

