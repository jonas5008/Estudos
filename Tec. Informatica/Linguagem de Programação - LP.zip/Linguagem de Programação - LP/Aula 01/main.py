print("hoje é a aula 02")
print("jogo da velha")
(2+2)
soma = 3 + 3
print("a soma é", soma)
subtracao = 10 - 3
print("a subtracao é", subtracao)

multiplicacao = 5 * 5
print("a multiplicacao é", multiplicacao)

divisao = 10 / 2
print("a divisao é", divisao)

pi = 3.14159

print("o valor de pi é", pi)
print(round(pi,2))

print(round(pi,1))

print(round(3.5,1))

print(round(3.5))


print(round(2.5))

print(round(7.5))

print(round(55.5))

















print(round(1.80))








nome = input("digite seu nome:")
print("meu nome é,", nome)


idade = input("digite sua idade:")
print("minha idade é,", idade)

altura = float(input("digite a sua altura:"))
print("a minha altura é", altura)















      








      





