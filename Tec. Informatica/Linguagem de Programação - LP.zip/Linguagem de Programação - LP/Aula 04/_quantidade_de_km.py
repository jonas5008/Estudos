num1 = int (input("diga a quantidade de km percorridos de um carro alugado:"))

print(num1)

km = 0.15

print(km)

num3= (num1*km)

print ("num3=",num3)

num2 = int (input("diga a quantidade de dias que o carro foi alugado:"))

print(num2)

preco = 60

print(preco)

num3= (num2*preco)

print ("num3=",num3)

