num1 = float (input("digite o primeiro numero:"))

print(num1)

num2 = float (input("digite o segundo numero:"))

print(num2)

if num1 > num2:

 print(f"O maior número é {num1}")
else:
    print(f"O maior número é {num2}")
