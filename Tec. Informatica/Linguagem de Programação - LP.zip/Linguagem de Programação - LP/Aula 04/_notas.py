#Considere um dicionario com 5 nomes de alunos e suas notas. Escreva um programa que calcule a media dessas notas.

alunos ={
"lucas":7,
"larissa":8.5,
"leticia":6,
"antonio":7.5,
"anderson":9.,
}

nota = alunos.values()
print(nota)

nota [7,8.5,6,7.5,9]

media = sum (nota) / 5

print (f"a media e {media}")


