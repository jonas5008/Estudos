dias = int(input("digite a quantidade de dias percorridos:"))

km = float(input("digite a quantidade de km percorridos:"))

total = (dias*60) + (km*0.15)

print(f"a quantidade de dias foi {dias} dias e o km foi {km} km o {total:.2f}")

