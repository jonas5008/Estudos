lanchonete ={
"produto":"preco",
"salgado":4.50,
"lanche":6.50,
"suco":3.00,
"refrigerante":3.50,
"doce":1.00,
}

print(lanchonete)

