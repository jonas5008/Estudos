L= [5,7,2,9,4,1,3]

# a)tamanho da lista
# b)maior da lista
# c)menor valor da lista
# d)soma de todos os elementos
# e)lista em ordem crescente
# f)lista em ordem decrescente

print(len(L))

print(max(L))

print(min(L))

print(sum(L))

print(sorted(L))

print(sorted(L,reverse=True))

