contador = 10
while contador >= 0:
    print(contador)
    contador = contador - 1

